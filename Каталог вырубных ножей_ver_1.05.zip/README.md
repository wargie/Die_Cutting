**Данный репозиторий содержит каталог вырубных ножей**
---
_Каждый лист в файле имеет наименование, соответствующее тому обородованию, для которого предполагается использование данного ножа._

`Current version: 1.01 - 21-03-2022`
- add some diecuts
- fixed some technical bugs

`Current version: 1.02 - 29-03-2022`
- add some diecuts

`Current version: 1.03 - 14-04-2022`
- add diecut № 087R - special figure

`Current version: 1.04 - 24-04-2022`
- add some diecuts for NilPeter and Lesko
- fixed bugs

`Current version: 1.05 - 26-04-2022`
- add diecut № 128R