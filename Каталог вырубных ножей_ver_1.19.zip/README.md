**Данный репозиторий содержит каталог вырубных ножей**
---
**_Каждый лист в файле имеет наименование, соответствующее тому обородованию, для которого предполагается использование данного ножа._**

`Current version: 1.01 - 21-03-2022`

- add some diecuts
- fixed some technical bugs

`Current version: 1.02 - 29-03-2022`

- add some diecuts

`Current version: 1.03 - 14-04-2022`

- add diecut № 087R - special figure

`Current version: 1.04 - 24-04-2022`

- add some diecuts for NilPeter and Lesko
- fixed bugs

`Current version: 1.05 - 26-04-2022`

- add diecut № 128R
- add diecut № 194R

`Current version: 1.06 - 03-02-2023`

- fix diecut № 271R
- add diecut № 276R

`Current version: 1.10 - 21-02-2023`

- add diecut № 009R for MarkAndy
- add diecut № 010R for MarkAndy
- fix shaft and size bugs

`Curren version: 1.11 - 15-03-2023`

- add diecut № 283R for NilPeter

`Curren version: 1.12 - 04-11-2023`

- add some diecuts for NilPeter, Lesko and MarkAndy
- try to make GUI on Python-base

`Curren version: 1.18 - 28-08-2024`

- 389R - final diecut for Nilpeter and small Lesko
- add a new section with figure cuts
- add a new section with perforation cuts

`Curren version: 1.19 - 09-10-2024`
- add some figure cuts
- add new regular cuts